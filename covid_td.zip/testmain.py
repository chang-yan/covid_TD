#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pygame
from testmenu import MainMenu

pygame.init()
m = MainMenu()
m.menu_run()


# In[ ]:




